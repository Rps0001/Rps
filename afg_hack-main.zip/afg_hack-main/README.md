# afg_hack
Hack facebook Afg  created by mohammad sultani



new command hack afg fb    TERMUX MASTER

pkg update && pkg upgrade

 pkg install python2

 pkg install git 

 pip2 installmechanize



 pip2 install requests

git clone https://github.com/Mohammadjan1122/afg_hack

cd afg_hack

 python2 Afg_master.py

user  telegram
pass t.me/sultani1122


## MY SOCIAL MEDIA
[![Github](https://img.shields.io/badge/Github-Ikuti-green?style=for-the-badge&logo=github)](https://github.com/Mohammadjan1122/)
[![Youtube](https://img.shields.io/badge/Youtube-Subscribe-green?style=for-the-badge&logo=Youtube)](https://www.youtube.com/channel/UCsjehdLYufdHOKyNwX_E6gg)
[![Instagram](https://img.shields.io/badge/Instagram-Ikuti-green?style=for-the-badge&logo=instagram)](https://Instagram.com/mohammad_sultani)
* Kalo masih kurang paham bisa hubungi WhatsAppðŸ‘‡
[![Telegram](https://img.shields.io/badge/Telegram-Hubungi-brightgreen?style=for-the-badge&logo=whatsapp)](https://t.me/sultani1122)
new command hack afg fb    TERMUX MASTER

pkg update && pkg upgrade

 pkg install python2

 pkg install git 

 pip2 installmechanize



 pip2 install requests

git clone https://github.com/Mohammadjan1122/afg_hack

cd afg_hack

 python2 Afg_master.py

user  telegram
pass t.me/sultani1122


## MY SOCIAL MEDIA
[![Github](https://img.shields.io/badge/Github-mohammad-green?style=for-the-badge&logo=github)](https://github.com/Mohammadjan1122/)
[![Youtube](https://img.shields.io/badge/Youtube-Subscribe-green?style=for-the-badge&logo=Youtube)](https://youtube.com/channel/UC6PezjDN1ofLSXn3onPxzpQ)
[![Instagram](https://img.shields.io/badge/Instagram-mohammad-green?style=for-the-badge&logo=instagram)](https://Instagram.com/mohammad_sultani)
* Kalo masih kurang paham bisa hubungi WhatsAppðŸ‘‡
[![Telegram](https://img.shields.io/badge/Telegram-Mohammad-brightgreen?style=for-the-badge&logo=Telegram)](https://t.me/sultani1122)
